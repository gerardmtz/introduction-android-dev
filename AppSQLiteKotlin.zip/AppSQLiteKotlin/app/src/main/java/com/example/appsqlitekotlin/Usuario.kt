package com.example.appsqlitekotlin

data class Usuario(val id: Int, val nombre: String, val edad:Int)